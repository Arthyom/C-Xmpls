﻿using System;
using System.Windows.Forms;

public class AnalizadorImagenes
{
	public AnalizadorImagenes( )
	{

	}

    public AnalizadorImagenes (  bitmap ImagenColor, bitmap ImagenGray )
    {

    }
}
