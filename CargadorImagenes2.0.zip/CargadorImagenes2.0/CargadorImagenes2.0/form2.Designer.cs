﻿namespace CargadorImagenes2._0
{
    partial class form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form2));
            this.ImagenEntrada = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Relieve = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.AfiladoBords = new System.Windows.Forms.RadioButton();
            this.DetectarBordeOpt = new System.Windows.Forms.RadioButton();
            this.RealzarBordeOpt = new System.Windows.Forms.RadioButton();
            this.RepuOpt = new System.Windows.Forms.RadioButton();
            this.DesEnfOpt = new System.Windows.Forms.RadioButton();
            this.EnfocarOpt = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.CalcularMascara = new System.Windows.Forms.Button();
            this.TextMascara = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.ImagenEnY = new System.Windows.Forms.RadioButton();
            this.ImagenEnZOpt = new System.Windows.Forms.RadioButton();
            this.ImagenEnXOpt = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.MascataTxtY = new System.Windows.Forms.TextBox();
            this.DetectarBorde = new System.Windows.Forms.Button();
            this.MascaraTextX = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.FriChenYOpt = new System.Windows.Forms.RadioButton();
            this.FriChenXOpt = new System.Windows.Forms.RadioButton();
            this.LaPlaceYOpy = new System.Windows.Forms.RadioButton();
            this.LaPlaceXOpt = new System.Windows.Forms.RadioButton();
            this.PrewittYOpt = new System.Windows.Forms.RadioButton();
            this.PrewittXOpt = new System.Windows.Forms.RadioButton();
            this.SolbelYOpt = new System.Windows.Forms.RadioButton();
            this.SobelXOpt = new System.Windows.Forms.RadioButton();
            this.RobertsYOpt = new System.Windows.Forms.RadioButton();
            this.RobertsXOpt = new System.Windows.Forms.RadioButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.desdeCarpetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.destinoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton5 = new System.Windows.Forms.ToolStripDropDownButton();
            this.cuadradoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenEntrada)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImagenEntrada
            // 
            this.ImagenEntrada.BackColor = System.Drawing.Color.Goldenrod;
            this.ImagenEntrada.Location = new System.Drawing.Point(4, 31);
            this.ImagenEntrada.Name = "ImagenEntrada";
            this.ImagenEntrada.Size = new System.Drawing.Size(482, 449);
            this.ImagenEntrada.TabIndex = 2;
            this.ImagenEntrada.TabStop = false;
            this.ImagenEntrada.Click += new System.EventHandler(this.ImagenEntrada_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(492, 88);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(457, 346);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(449, 320);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Umbralizacion";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.trackBar1);
            this.groupBox1.Location = new System.Drawing.Point(6, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(437, 111);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Otsu";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(425, 35);
            this.button1.TabIndex = 2;
            this.button1.Text = "Otsu Automatico";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(45, 19);
            this.trackBar1.Maximum = 254;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(386, 45);
            this.trackBar1.TabIndex = 0;
            this.trackBar1.Value = 1;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(449, 320);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Morfologia";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(437, 132);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operaciones";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(308, 19);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(123, 35);
            this.button8.TabIndex = 9;
            this.button8.Text = "Dilatacion";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(308, 55);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(123, 35);
            this.button7.TabIndex = 8;
            this.button7.Text = "Dilatacion";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(158, 59);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(123, 35);
            this.button6.TabIndex = 7;
            this.button6.Text = "Dilatacion";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(6, 18);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(123, 35);
            this.button3.TabIndex = 4;
            this.button3.Text = "Dilatacion";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(158, 18);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(123, 35);
            this.button5.TabIndex = 6;
            this.button5.Text = "Dilatacion";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 55);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 35);
            this.button2.TabIndex = 3;
            this.button2.Text = "Dilatacion";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabPage3.Size = new System.Drawing.Size(449, 320);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Histograma";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(449, 320);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Filtros";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButton11);
            this.groupBox5.Controls.Add(this.radioButton9);
            this.groupBox5.Location = new System.Drawing.Point(4, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(442, 36);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Usar Como";
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(371, 19);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(66, 17);
            this.radioButton11.TabIndex = 6;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Mediana";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(6, 19);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(69, 17);
            this.radioButton9.TabIndex = 4;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Promedio";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Relieve);
            this.groupBox4.Controls.Add(this.radioButton7);
            this.groupBox4.Controls.Add(this.AfiladoBords);
            this.groupBox4.Controls.Add(this.DetectarBordeOpt);
            this.groupBox4.Controls.Add(this.RealzarBordeOpt);
            this.groupBox4.Controls.Add(this.RepuOpt);
            this.groupBox4.Controls.Add(this.DesEnfOpt);
            this.groupBox4.Controls.Add(this.EnfocarOpt);
            this.groupBox4.Location = new System.Drawing.Point(4, 45);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(442, 77);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Predefinidos";
            // 
            // Relieve
            // 
            this.Relieve.AutoSize = true;
            this.Relieve.Location = new System.Drawing.Point(334, 33);
            this.Relieve.Name = "Relieve";
            this.Relieve.Size = new System.Drawing.Size(61, 17);
            this.Relieve.TabIndex = 10;
            this.Relieve.TabStop = true;
            this.Relieve.Text = "Relieve";
            this.Relieve.UseVisualStyleBackColor = true;
            this.Relieve.CheckedChanged += new System.EventHandler(this.Relieve_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(334, 10);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(102, 17);
            this.radioButton7.TabIndex = 9;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Desafilar Bordes";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // AfiladoBords
            // 
            this.AfiladoBords.AutoSize = true;
            this.AfiladoBords.Location = new System.Drawing.Point(218, 33);
            this.AfiladoBords.Name = "AfiladoBords";
            this.AfiladoBords.Size = new System.Drawing.Size(84, 17);
            this.AfiladoBords.TabIndex = 8;
            this.AfiladoBords.TabStop = true;
            this.AfiladoBords.Text = "Afilar Bordes";
            this.AfiladoBords.UseVisualStyleBackColor = true;
            this.AfiladoBords.CheckedChanged += new System.EventHandler(this.AfiladoBords_CheckedChanged);
            // 
            // DetectarBordeOpt
            // 
            this.DetectarBordeOpt.AutoSize = true;
            this.DetectarBordeOpt.Location = new System.Drawing.Point(218, 10);
            this.DetectarBordeOpt.Name = "DetectarBordeOpt";
            this.DetectarBordeOpt.Size = new System.Drawing.Size(97, 17);
            this.DetectarBordeOpt.TabIndex = 7;
            this.DetectarBordeOpt.TabStop = true;
            this.DetectarBordeOpt.Text = "Detectar Borde";
            this.DetectarBordeOpt.UseVisualStyleBackColor = true;
            this.DetectarBordeOpt.CheckedChanged += new System.EventHandler(this.DetectarBordeOpt_CheckedChanged);
            // 
            // RealzarBordeOpt
            // 
            this.RealzarBordeOpt.AutoSize = true;
            this.RealzarBordeOpt.Location = new System.Drawing.Point(107, 33);
            this.RealzarBordeOpt.Name = "RealzarBordeOpt";
            this.RealzarBordeOpt.Size = new System.Drawing.Size(92, 17);
            this.RealzarBordeOpt.TabIndex = 6;
            this.RealzarBordeOpt.TabStop = true;
            this.RealzarBordeOpt.Text = "Realzar Borde";
            this.RealzarBordeOpt.UseVisualStyleBackColor = true;
            this.RealzarBordeOpt.CheckedChanged += new System.EventHandler(this.RealzarBordeOpt_CheckedChanged);
            // 
            // RepuOpt
            // 
            this.RepuOpt.AutoSize = true;
            this.RepuOpt.Location = new System.Drawing.Point(107, 10);
            this.RepuOpt.Name = "RepuOpt";
            this.RepuOpt.Size = new System.Drawing.Size(71, 17);
            this.RepuOpt.TabIndex = 5;
            this.RepuOpt.TabStop = true;
            this.RepuOpt.Text = "Repujado";
            this.RepuOpt.UseVisualStyleBackColor = true;
            this.RepuOpt.CheckedChanged += new System.EventHandler(this.RepuOpt_CheckedChanged);
            // 
            // DesEnfOpt
            // 
            this.DesEnfOpt.AutoSize = true;
            this.DesEnfOpt.Location = new System.Drawing.Point(6, 33);
            this.DesEnfOpt.Name = "DesEnfOpt";
            this.DesEnfOpt.Size = new System.Drawing.Size(81, 17);
            this.DesEnfOpt.TabIndex = 4;
            this.DesEnfOpt.TabStop = true;
            this.DesEnfOpt.Text = "DesEnfocar";
            this.DesEnfOpt.UseVisualStyleBackColor = true;
            this.DesEnfOpt.CheckedChanged += new System.EventHandler(this.DesEnfOpt_CheckedChanged);
            // 
            // EnfocarOpt
            // 
            this.EnfocarOpt.AutoSize = true;
            this.EnfocarOpt.Location = new System.Drawing.Point(6, 10);
            this.EnfocarOpt.Name = "EnfocarOpt";
            this.EnfocarOpt.Size = new System.Drawing.Size(62, 17);
            this.EnfocarOpt.TabIndex = 3;
            this.EnfocarOpt.TabStop = true;
            this.EnfocarOpt.Text = "Enfocar";
            this.EnfocarOpt.UseVisualStyleBackColor = true;
            this.EnfocarOpt.CheckedChanged += new System.EventHandler(this.EnfocarOpt_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.CalcularMascara);
            this.groupBox3.Controls.Add(this.TextMascara);
            this.groupBox3.Location = new System.Drawing.Point(3, 122);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(443, 196);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filtros Personalizados";
            // 
            // CalcularMascara
            // 
            this.CalcularMascara.Location = new System.Drawing.Point(7, 171);
            this.CalcularMascara.Name = "CalcularMascara";
            this.CalcularMascara.Size = new System.Drawing.Size(431, 22);
            this.CalcularMascara.TabIndex = 1;
            this.CalcularMascara.Text = "Filtrar";
            this.CalcularMascara.UseVisualStyleBackColor = true;
            this.CalcularMascara.Click += new System.EventHandler(this.CalcularMascara_Click);
            // 
            // TextMascara
            // 
            this.TextMascara.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.TextMascara.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextMascara.Location = new System.Drawing.Point(6, 19);
            this.TextMascara.Multiline = true;
            this.TextMascara.Name = "TextMascara";
            this.TextMascara.Size = new System.Drawing.Size(431, 146);
            this.TextMascara.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox8);
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(449, 320);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Bordes";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.ImagenEnY);
            this.groupBox8.Controls.Add(this.ImagenEnZOpt);
            this.groupBox8.Controls.Add(this.ImagenEnXOpt);
            this.groupBox8.Location = new System.Drawing.Point(4, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(442, 39);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Predefinidos";
            // 
            // ImagenEnY
            // 
            this.ImagenEnY.AutoSize = true;
            this.ImagenEnY.Location = new System.Drawing.Point(347, 16);
            this.ImagenEnY.Name = "ImagenEnY";
            this.ImagenEnY.Size = new System.Drawing.Size(86, 17);
            this.ImagenEnY.TabIndex = 9;
            this.ImagenEnY.Text = "Imagen En Y";
            this.ImagenEnY.UseVisualStyleBackColor = true;
            // 
            // ImagenEnZOpt
            // 
            this.ImagenEnZOpt.AutoSize = true;
            this.ImagenEnZOpt.Location = new System.Drawing.Point(179, 16);
            this.ImagenEnZOpt.Name = "ImagenEnZOpt";
            this.ImagenEnZOpt.Size = new System.Drawing.Size(86, 17);
            this.ImagenEnZOpt.TabIndex = 7;
            this.ImagenEnZOpt.Text = "Imagen En Z";
            this.ImagenEnZOpt.UseVisualStyleBackColor = true;
            // 
            // ImagenEnXOpt
            // 
            this.ImagenEnXOpt.AutoSize = true;
            this.ImagenEnXOpt.Location = new System.Drawing.Point(9, 16);
            this.ImagenEnXOpt.Name = "ImagenEnXOpt";
            this.ImagenEnXOpt.Size = new System.Drawing.Size(86, 17);
            this.ImagenEnXOpt.TabIndex = 5;
            this.ImagenEnXOpt.Text = "Imagen En X";
            this.ImagenEnXOpt.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.MascataTxtY);
            this.groupBox7.Controls.Add(this.DetectarBorde);
            this.groupBox7.Controls.Add(this.MascaraTextX);
            this.groupBox7.Location = new System.Drawing.Point(3, 121);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(443, 196);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Filtros Personalizados";
            // 
            // MascataTxtY
            // 
            this.MascataTxtY.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.MascataTxtY.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MascataTxtY.Location = new System.Drawing.Point(245, 19);
            this.MascataTxtY.Multiline = true;
            this.MascataTxtY.Name = "MascataTxtY";
            this.MascataTxtY.Size = new System.Drawing.Size(193, 146);
            this.MascataTxtY.TabIndex = 2;
            this.MascataTxtY.TextChanged += new System.EventHandler(this.MascataTxtY_TextChanged);
            // 
            // DetectarBorde
            // 
            this.DetectarBorde.Location = new System.Drawing.Point(7, 171);
            this.DetectarBorde.Name = "DetectarBorde";
            this.DetectarBorde.Size = new System.Drawing.Size(431, 22);
            this.DetectarBorde.TabIndex = 1;
            this.DetectarBorde.Text = "Detectar";
            this.DetectarBorde.UseVisualStyleBackColor = true;
            this.DetectarBorde.Click += new System.EventHandler(this.DetectarBorde_Click);
            // 
            // MascaraTextX
            // 
            this.MascaraTextX.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.MascaraTextX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MascaraTextX.Location = new System.Drawing.Point(6, 19);
            this.MascaraTextX.Multiline = true;
            this.MascaraTextX.Name = "MascaraTextX";
            this.MascaraTextX.Size = new System.Drawing.Size(193, 146);
            this.MascaraTextX.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.FriChenYOpt);
            this.groupBox6.Controls.Add(this.FriChenXOpt);
            this.groupBox6.Controls.Add(this.LaPlaceYOpy);
            this.groupBox6.Controls.Add(this.LaPlaceXOpt);
            this.groupBox6.Controls.Add(this.PrewittYOpt);
            this.groupBox6.Controls.Add(this.PrewittXOpt);
            this.groupBox6.Controls.Add(this.SolbelYOpt);
            this.groupBox6.Controls.Add(this.SobelXOpt);
            this.groupBox6.Controls.Add(this.RobertsYOpt);
            this.groupBox6.Controls.Add(this.RobertsXOpt);
            this.groupBox6.Location = new System.Drawing.Point(4, 48);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(442, 67);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Predefinidos";
            // 
            // FriChenYOpt
            // 
            this.FriChenYOpt.AutoSize = true;
            this.FriChenYOpt.Location = new System.Drawing.Point(365, 42);
            this.FriChenYOpt.Name = "FriChenYOpt";
            this.FriChenYOpt.Size = new System.Drawing.Size(68, 17);
            this.FriChenYOpt.TabIndex = 12;
            this.FriChenYOpt.Text = "FriChenY";
            this.FriChenYOpt.UseVisualStyleBackColor = true;
            this.FriChenYOpt.CheckedChanged += new System.EventHandler(this.FriChenYOpt_CheckedChanged);
            // 
            // FriChenXOpt
            // 
            this.FriChenXOpt.AutoSize = true;
            this.FriChenXOpt.Location = new System.Drawing.Point(365, 19);
            this.FriChenXOpt.Name = "FriChenXOpt";
            this.FriChenXOpt.Size = new System.Drawing.Size(71, 17);
            this.FriChenXOpt.TabIndex = 11;
            this.FriChenXOpt.Text = "FriChen X";
            this.FriChenXOpt.UseVisualStyleBackColor = true;
            this.FriChenXOpt.CheckedChanged += new System.EventHandler(this.FriChenXOpt_CheckedChanged);
            // 
            // LaPlaceYOpy
            // 
            this.LaPlaceYOpy.AutoSize = true;
            this.LaPlaceYOpy.Location = new System.Drawing.Point(269, 42);
            this.LaPlaceYOpy.Name = "LaPlaceYOpy";
            this.LaPlaceYOpy.Size = new System.Drawing.Size(74, 17);
            this.LaPlaceYOpy.TabIndex = 10;
            this.LaPlaceYOpy.Text = "LaPlace Y";
            this.LaPlaceYOpy.UseVisualStyleBackColor = true;
            this.LaPlaceYOpy.CheckedChanged += new System.EventHandler(this.LaPlaceYOpy_CheckedChanged);
            // 
            // LaPlaceXOpt
            // 
            this.LaPlaceXOpt.AutoSize = true;
            this.LaPlaceXOpt.Location = new System.Drawing.Point(269, 19);
            this.LaPlaceXOpt.Name = "LaPlaceXOpt";
            this.LaPlaceXOpt.Size = new System.Drawing.Size(74, 17);
            this.LaPlaceXOpt.TabIndex = 9;
            this.LaPlaceXOpt.TabStop = true;
            this.LaPlaceXOpt.Text = "LaPlace X";
            this.LaPlaceXOpt.UseVisualStyleBackColor = true;
            this.LaPlaceXOpt.CheckedChanged += new System.EventHandler(this.LaPlaceXOpt_CheckedChanged);
            // 
            // PrewittYOpt
            // 
            this.PrewittYOpt.AutoSize = true;
            this.PrewittYOpt.Location = new System.Drawing.Point(179, 42);
            this.PrewittYOpt.Name = "PrewittYOpt";
            this.PrewittYOpt.Size = new System.Drawing.Size(67, 17);
            this.PrewittYOpt.TabIndex = 8;
            this.PrewittYOpt.TabStop = true;
            this.PrewittYOpt.Text = "Prewitt Y";
            this.PrewittYOpt.UseVisualStyleBackColor = true;
            this.PrewittYOpt.CheckedChanged += new System.EventHandler(this.PrewittYOpt_CheckedChanged);
            // 
            // PrewittXOpt
            // 
            this.PrewittXOpt.AutoSize = true;
            this.PrewittXOpt.Location = new System.Drawing.Point(179, 19);
            this.PrewittXOpt.Name = "PrewittXOpt";
            this.PrewittXOpt.Size = new System.Drawing.Size(67, 17);
            this.PrewittXOpt.TabIndex = 7;
            this.PrewittXOpt.TabStop = true;
            this.PrewittXOpt.Text = "Prewitt X";
            this.PrewittXOpt.UseVisualStyleBackColor = true;
            this.PrewittXOpt.CheckedChanged += new System.EventHandler(this.PrewittXOpt_CheckedChanged);
            // 
            // SolbelYOpt
            // 
            this.SolbelYOpt.AutoSize = true;
            this.SolbelYOpt.Location = new System.Drawing.Point(100, 42);
            this.SolbelYOpt.Name = "SolbelYOpt";
            this.SolbelYOpt.Size = new System.Drawing.Size(62, 17);
            this.SolbelYOpt.TabIndex = 6;
            this.SolbelYOpt.TabStop = true;
            this.SolbelYOpt.Text = "Sobel Y";
            this.SolbelYOpt.UseVisualStyleBackColor = true;
            this.SolbelYOpt.CheckedChanged += new System.EventHandler(this.SolbelYOpt_CheckedChanged);
            // 
            // SobelXOpt
            // 
            this.SobelXOpt.AutoSize = true;
            this.SobelXOpt.Location = new System.Drawing.Point(100, 19);
            this.SobelXOpt.Name = "SobelXOpt";
            this.SobelXOpt.Size = new System.Drawing.Size(62, 17);
            this.SobelXOpt.TabIndex = 5;
            this.SobelXOpt.TabStop = true;
            this.SobelXOpt.Text = "Sobel X";
            this.SobelXOpt.UseVisualStyleBackColor = true;
            this.SobelXOpt.CheckedChanged += new System.EventHandler(this.SobelXOpt_CheckedChanged);
            // 
            // RobertsYOpt
            // 
            this.RobertsYOpt.AutoSize = true;
            this.RobertsYOpt.Location = new System.Drawing.Point(9, 42);
            this.RobertsYOpt.Name = "RobertsYOpt";
            this.RobertsYOpt.Size = new System.Drawing.Size(72, 17);
            this.RobertsYOpt.TabIndex = 4;
            this.RobertsYOpt.TabStop = true;
            this.RobertsYOpt.Text = "Roberts Y";
            this.RobertsYOpt.UseVisualStyleBackColor = true;
            this.RobertsYOpt.CheckedChanged += new System.EventHandler(this.RobertsYOpt_CheckedChanged);
            // 
            // RobertsXOpt
            // 
            this.RobertsXOpt.AutoSize = true;
            this.RobertsXOpt.Location = new System.Drawing.Point(9, 19);
            this.RobertsXOpt.Name = "RobertsXOpt";
            this.RobertsXOpt.Size = new System.Drawing.Size(72, 17);
            this.RobertsXOpt.TabIndex = 3;
            this.RobertsXOpt.TabStop = true;
            this.RobertsXOpt.Text = "Roberts X";
            this.RobertsXOpt.UseVisualStyleBackColor = true;
            this.RobertsXOpt.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton3,
            this.toolStripDropDownButton5,
            this.toolStripDropDownButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(955, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.desdeCarpetaToolStripMenuItem,
            this.destinoToolStripMenuItem});
            this.toolStripDropDownButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton3.Image")));
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(61, 22);
            this.toolStripDropDownButton3.Text = "Pruevas";
            // 
            // desdeCarpetaToolStripMenuItem
            // 
            this.desdeCarpetaToolStripMenuItem.Name = "desdeCarpetaToolStripMenuItem";
            this.desdeCarpetaToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.desdeCarpetaToolStripMenuItem.Text = "Desde Carpeta";
            // 
            // destinoToolStripMenuItem
            // 
            this.destinoToolStripMenuItem.Name = "destinoToolStripMenuItem";
            this.destinoToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.destinoToolStripMenuItem.Text = "Destino";
            // 
            // toolStripDropDownButton5
            // 
            this.toolStripDropDownButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cuadradoToolStripMenuItem});
            this.toolStripDropDownButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton5.Image")));
            this.toolStripDropDownButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton5.Name = "toolStripDropDownButton5";
            this.toolStripDropDownButton5.Size = new System.Drawing.Size(86, 22);
            this.toolStripDropDownButton5.Text = "Predefinidos";
            // 
            // cuadradoToolStripMenuItem
            // 
            this.cuadradoToolStripMenuItem.Name = "cuadradoToolStripMenuItem";
            this.cuadradoToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.cuadradoToolStripMenuItem.Text = "Cuadrado";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(96, 22);
            this.toolStripDropDownButton1.Text = "Configuracion";
            // 
            // form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 484);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.ImagenEntrada);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "form2";
            this.Text = "form2";
            this.Load += new System.EventHandler(this.form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ImagenEntrada)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ImagenEntrada;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripMenuItem desdeCarpetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem destinoToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton5;
        private System.Windows.Forms.ToolStripMenuItem cuadradoToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton Relieve;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton AfiladoBords;
        private System.Windows.Forms.RadioButton DetectarBordeOpt;
        private System.Windows.Forms.RadioButton RealzarBordeOpt;
        private System.Windows.Forms.RadioButton RepuOpt;
        private System.Windows.Forms.RadioButton DesEnfOpt;
        private System.Windows.Forms.RadioButton EnfocarOpt;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button CalcularMascara;
        private System.Windows.Forms.TextBox TextMascara;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button DetectarBorde;
        private System.Windows.Forms.TextBox MascaraTextX;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton LaPlaceYOpy;
        private System.Windows.Forms.RadioButton LaPlaceXOpt;
        private System.Windows.Forms.RadioButton PrewittYOpt;
        private System.Windows.Forms.RadioButton PrewittXOpt;
        private System.Windows.Forms.RadioButton SolbelYOpt;
        private System.Windows.Forms.RadioButton SobelXOpt;
        private System.Windows.Forms.RadioButton RobertsYOpt;
        private System.Windows.Forms.RadioButton RobertsXOpt;
        private System.Windows.Forms.TextBox MascataTxtY;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton ImagenEnY;
        private System.Windows.Forms.RadioButton ImagenEnZOpt;
        private System.Windows.Forms.RadioButton ImagenEnXOpt;
        private System.Windows.Forms.RadioButton FriChenYOpt;
        private System.Windows.Forms.RadioButton FriChenXOpt;
    }
}